//1. Declaracion del modulo TACO
//modulo que integra RAM, DEMUX y ALU
module TACO(

    input [4:0] addr,
    input [31:0] data_in,
    input EN,
    input [2:0] alu_op,
    input sel,

    output [31:0] data_out,
    output [31:0] alu_result
);

//2. Declaracion de conexiones internas
wire [31:0] ram_data;
wire [31:0] demux0;
wire [31:0] demux1;

//3. Instancia del modulo RAM
RAM memoria(
    .addr(addr),
    .data_in(data_in),
    .EN(EN),
    .data_out(ram_data)
);

//4. Instancia del DEMUX
DEMUX demux_inst(
    .data_in(ram_data),
    .sel(sel),
    .out0(demux0),
    .out1(demux1)
);

//5. Instancia de la ALU
ALU alu_inst(
    .A(demux0),
    .B(demux1),
    .alu_op(alu_op),
    .result(alu_result)
);

//6. Salida directa de la RAM
assign data_out = ram_data;

endmodule
