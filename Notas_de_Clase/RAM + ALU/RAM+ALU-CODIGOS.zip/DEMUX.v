//1. Declaracion del modulo DEMUX
//y sus entradas y salidas
module DEMUX(
    input [31:0] data_in,
    input sel,
    output reg [31:0] out0,
    output reg [31:0] out1
);

//2. Logica de seleccion del demultiplexor
//dependiendo del valor de sel
always @(*)
begin

    case(sel)

        //3. Si sel = 0 el dato va a out0
        1'b0:
        begin
            out0 = data_in;
            out1 = 32'd0;
        end

        //4. Si sel = 1 el dato va a out1
        1'b1:
        begin
            out0 = 32'd0;
            out1 = data_in;
        end

    endcase

end

endmodule
