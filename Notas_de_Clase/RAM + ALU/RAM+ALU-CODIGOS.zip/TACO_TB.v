//1. Declaracion del modulo de prueba
module taco_tb;

//2. Declaracion de se�ales de prueba
reg [4:0] addr;
reg [31:0] data_in;
reg EN;
reg [2:0] alu_op;
reg sel;

wire [31:0] data_out;
wire [31:0] alu_result;

//3. Instancia del modulo TACO
TACO uut(
    .addr(addr),
    .data_in(data_in),
    .EN(EN),
    .alu_op(alu_op),
    .sel(sel),
    .data_out(data_out),
    .alu_result(alu_result)
);

//4. Secuencia de pruebas
initial
begin

    //5. Escritura en RAM
    addr = 5'd10;
    data_in = 32'd15;
    EN = 1;
    #10;

    //6. Lectura de RAM
    EN = 0;
    #10;

    //7. Cambio de direccion
    addr = 5'd1;
    #10;

    //8. Operacion ALU suma
    alu_op = 3'b010;
    sel = 0;
    #10;

    //9. Operacion ALU resta
    alu_op = 3'b110;
    sel = 1;
    #10;

end

endmodule
