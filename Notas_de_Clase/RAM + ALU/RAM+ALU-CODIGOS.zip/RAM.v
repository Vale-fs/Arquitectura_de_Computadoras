//1. Declaracion del modulo RAM
//y sus entradas y salidas
module RAM(
    input [4:0] addr,
    input [31:0] data_in,
    input EN,
    output [31:0] data_out
);

//2. Declaracion de componentes internos
//Wires: NA, Reg: si
//arreglo bidimensional de memoria
reg [31:0] MEM [0:31];

//3. Inicializacion de algunos valores de memoria
initial
begin
    MEM[0] = 32'd254;
    MEM[1] = 32'd4;
    MEM[2] = 32'd36;
    MEM[3] = 32'd12;
    MEM[4] = 32'd8;
    MEM[5] = 32'd25;
    MEM[6] = 32'd98;
    MEM[7] = 32'd45;
    MEM[8] = 32'd22;
end

//4. Escritura en memoria
//si EN = 1 se guarda data_in en la direccion addr
always @(*)
begin
    if(EN)
        MEM[addr] = data_in;
end

//5. Lectura de la memoria en la posicion addr
assign data_out = MEM[addr];

endmodule
