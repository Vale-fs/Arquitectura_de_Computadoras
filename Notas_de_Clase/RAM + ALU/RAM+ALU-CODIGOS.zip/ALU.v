//1. Declaracion del modulo ALU
//y sus entradas y salidas
module ALU(
    input [31:0] A,
    input [31:0] B,
    input [2:0] alu_op,
    output reg [31:0] result
);

//2. Logica de operaciones de la ALU
//dependiendo del valor de alu_op
always @(*)
begin

    case(alu_op)

        //3. Operacion AND
        3'b000: result = A & B;

        //4. Operacion OR
        3'b001: result = A | B;

        //5. Operacion SUMA
        3'b010: result = A + B;

        //6. Operacion RESTA
        3'b110: result = A - B;

        //7. Operacion SET LESS THAN
        3'b111: result = (A < B);

        //8. Operacion NOR
        3'b100: result = ~(A | B);

        //9. Caso por defecto
        default: result = 32'd0;

    endcase

end

endmodule
